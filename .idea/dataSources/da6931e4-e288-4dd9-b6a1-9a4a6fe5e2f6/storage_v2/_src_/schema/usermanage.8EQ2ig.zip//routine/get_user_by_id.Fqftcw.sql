create
    definer = root@localhost procedure get_user_by_id(IN user_id int)
BEGIN

    SELECT *

    FROM user

    where id = user_id;

END;

