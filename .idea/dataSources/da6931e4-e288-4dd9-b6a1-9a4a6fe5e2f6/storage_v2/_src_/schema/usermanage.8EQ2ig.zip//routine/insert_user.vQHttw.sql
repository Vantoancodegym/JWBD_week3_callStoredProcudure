create
    definer = root@localhost procedure insert_user(IN user_id int, IN user_name varchar(50), IN user_email varchar(50))
BEGIN

    INSERT INTO user VALUES(user_id, user_name, user_email);

END;

